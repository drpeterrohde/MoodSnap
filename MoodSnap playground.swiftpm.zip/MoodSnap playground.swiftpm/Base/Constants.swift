import SwiftUI

let dayInterval = 60 * 60 * 24
let weekInterval = 7 * dayInterval
let monthInterval = 4 * weekInterval
let threeMonthInterval = 3 * monthInterval
let sixMonthInterval = 6 * monthInterval
let yearInterval = 365 * dayInterval

let zeroGraphicalBarOffset = 0.2
let midLineWidth = 3.0

let symptomList = [
    "Anhedonia",
    "Increased apetite",
    "Reduced apetite",
    "Compul-sions",
    "Dissoc-iation",
    "Euphoria",
    "Flashbacks",
    "Mixed state",
    "Nightmares",
    "Panic attacks",
    "Paranoia",
    "Physical",
    "Psychosis",
    "Restless",
    "Rumination",
    "Increased sleep",
    "Poor sleep",
    "Self harm",
    "Suicidal thoughts"
]

let activityList = [
    "Alcohol", 
    "Caffeine", 
    "Excercise",
    "Meditation",
    "Missed medication",
    "Sexual activity",
    "Positive socialising",
    "Negative socialising",
    "Substance use",
    "Therapy"
]
