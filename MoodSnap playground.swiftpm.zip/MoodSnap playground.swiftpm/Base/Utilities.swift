import SwiftUI

func totalSymptoms(moodSnap: MoodSnapStruct, settings: SettingsStruct) -> Int {
    var mask: [Bool] = []
    for i in 0..<symptomList.count {
        mask.append(moodSnap.symptoms[i] && settings.symptomVisibility[i])
    }
    let total = mask.filter{$0}.count
    return total
}

func totalActivities(moodSnap: MoodSnapStruct, settings: SettingsStruct) -> Int {
    var mask: [Bool] = []
    for i in 0..<activityList.count {
        mask.append(moodSnap.activities[i] && settings.activityVisibility[i])
    }
    let total = mask.filter{$0}.count
    return total
}

func todaysDateComponents() -> DateComponents {
    return Calendar.current.dateComponents([.day, .month, .year], from: Date())
}

func subtractDaysFromDate(date: Date, days: Int) -> Date? {
    let dayComp = DateComponents(day: -days)
    let date = Calendar.current.date(byAdding: dayComp, to: date)
    return date
}

func duplicateMoodSnapStruct(moodSnap: MoodSnapStruct) {
    var duplicate = moodSnap
    duplicate.id = UUID()
}

func deleteHistoryItem(moodSnaps: [MoodSnapStruct], moodSnap: MoodSnapStruct) -> [MoodSnapStruct] {
    return moodSnaps.filter {$0.id != moodSnap.id}
}
