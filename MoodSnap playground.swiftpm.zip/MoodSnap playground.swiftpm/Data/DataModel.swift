import Foundation
import SwiftUI

struct DataStoreStruct: Identifiable, Codable {
    var id: UUID = UUID()
    var settings: SettingsStruct = SettingsStruct()
    var moodSnaps: [MoodSnapStruct] = makeDemoData(size: 100)
}

class DataStore: ObservableObject {
    @Published var data: [DataStoreStruct] = [DataStoreStruct()]
    
    private static func fileURL() throws -> URL {
        var url: URL
        do {
            try url = FileManager.default.url(for: .documentDirectory,
                                       in: .userDomainMask,
                                       appropriateFor: nil,
                                       create: false)
            .appendingPathComponent("moodsnap.data")
        } catch {
            try url = FileManager.default.url(for: .documentDirectory, // by me ???
                                         in: .userDomainMask,
                                         appropriateFor: nil,
                                         create: true)
                .appendingPathComponent("moodsnap.data")
        }
        return url
    }
    
    static func load(completion: @escaping (Result<[DataStoreStruct], Error>)->Void) {
        DispatchQueue.global(qos: .background).async {
            do {
                let fileURL = try fileURL()
                guard let file = try? FileHandle(forReadingFrom: fileURL) else {
                    DispatchQueue.main.async {
                        completion(.success([]))
                    }
                    return
                }
                let data = try JSONDecoder().decode([DataStoreStruct].self, from: file.availableData)
                DispatchQueue.main.async {
                    completion(.success(data))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
        static func save(data: [DataStoreStruct], completion: @escaping (Result<Int, Error>)->Void) {
            DispatchQueue.global(qos: .background).async {
                do {
                    let data = try JSONEncoder().encode(data)
                    let outfile = try fileURL()
                    try data.write(to: outfile)
                    DispatchQueue.main.async {
                        completion(.success(data.count))
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(.failure(error))
                    }
                }
            }
        }
}
