import SwiftUI

struct HistoryMediaView: View {
    let moodSnap: MoodSnapStruct
    let settings: SettingsStruct
    
    var body: some View {
        Group {
            Divider()
            Spacer()
            if let image = UIImage.loadImageFromDiskWith(fileName: moodSnap.id.uuidString) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
            }
        }
    }
}
