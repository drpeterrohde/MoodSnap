import SwiftUI

struct MoodLevelsView: View {
    let moodSnap: MoodSnapStruct
    let settings: SettingsStruct
    
    var body: some View {
        GeometryReader{geometry in
            let hBarStep: CGFloat = (geometry.size.width-35)/4
            
            ZStack{
                // Grid
                Path { path in
                    let offsetX: CGFloat = 20.0
                    let offsetY: CGFloat = 8.5
                    let stepY: CGFloat = 14.7
                    
                    // Vertical gridlines
                    for i in 0...4 {
                        path.move(to: CGPoint(x: Int(offsetX+CGFloat(i)*hBarStep), y: Int(offsetY)))
                        path.addLine(to: CGPoint(x: Int(offsetX+CGFloat(i)*hBarStep), y: Int(offsetY+3*stepY)))
                    }
                    
                    // Horizontal gridlines
                    for i in 0...3 {
                        path.move(to: CGPoint(x: Int(offsetX), y: Int(offsetY+CGFloat(i)*stepY)))
                        path.addLine(to: CGPoint(x: Int(offsetX+4*hBarStep), y: Int(offsetY+CGFloat(i)*stepY)))
                    }
                    
                    path.closeSubpath()
                }.stroke(themes[settings.theme].gridColor, lineWidth: 1)
                
                // Graph
                VStack(alignment: .leading, spacing: 0) {
                    HStack{
                        Text("E").font(Font.system(size: themes[settings.theme].hBarFontSize, design: .monospaced))
                        RoundedRectangle(cornerRadius: themes[settings.theme].hBarRadius, style:.continuous).foregroundColor(themes[settings.theme].elevationColor).frame(width: (moodSnap.elevation * hBarStep + themes[settings.theme].hBarHeight), height: themes[settings.theme].hBarHeight)
                        Spacer()
                    }
                    HStack{
                        Text("D").font(Font.system(size: themes[settings.theme].hBarFontSize, design: .monospaced))
                        RoundedRectangle(cornerRadius: themes[settings.theme].hBarRadius, style: .continuous).foregroundColor(themes[settings.theme].depressionColor).frame(width: (moodSnap.depression * hBarStep + themes[settings.theme].hBarHeight), height: themes[settings.theme].hBarHeight)
                        Spacer()
                    }
                    HStack{
                        Text("A").font(Font.system(size: themes[settings.theme].hBarFontSize, design: .monospaced))
                        RoundedRectangle(cornerRadius: themes[settings.theme].hBarRadius, style: .continuous).foregroundColor(themes[settings.theme].anxietyColor).frame(width: (moodSnap.anxiety * hBarStep + themes[settings.theme].hBarHeight), height: themes[settings.theme].hBarHeight)
                        Spacer()
                    }
                    HStack{
                        Text("I").font(Font.system(size: themes[settings.theme].hBarFontSize, design: .monospaced))
                        RoundedRectangle(cornerRadius: themes[settings.theme].hBarRadius, style: .continuous).foregroundColor(themes[settings.theme].irritabilityColor).frame(width: (moodSnap.irritability * hBarStep + themes[settings.theme].hBarHeight), height: themes[settings.theme].hBarHeight)
                    }
                }
            }
        }.frame(height: 60)
    }
}
