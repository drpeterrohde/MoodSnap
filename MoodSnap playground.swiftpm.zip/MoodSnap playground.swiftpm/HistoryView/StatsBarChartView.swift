//import SwiftUI
//
//struct StatsBarChartView: View {
//    let title: String
//    let data: [Int]
//    let color: Color
//    let settings: SettingsStruct
//    
//    var body: some View {
//        Label(title, systemImage: "clock").font(.caption).labelStyle(.titleOnly)
//        
//            // Gridlines
//            
//            // Bar chart
//            GeometryReader{geometry in
//                let vBarWidth: CGFloat = 0.8*(geometry.size.width-40)/CGFloat(data.count)
//                
//                VStack(alignment: .center){
//                    HStack(alignment: .bottom) {
//                    ForEach(0..<(data.count)) {i in
//                        if(data[i] >= 0) {
//                        RoundedRectangle(cornerRadius: themes[settings.theme].hBarRadius, style: .continuous).foregroundColor(color).frame(width: vBarWidth, height: CGFloat(data[i]+1)*themes[settings.theme].vBarStep)
//                            
//                        } else {
//                            RoundedRectangle(cornerRadius: themes[settings.theme].hBarRadius, style: .continuous).foregroundColor(color).opacity(0).frame(width: vBarWidth, height: CGFloat(data[i]+1)*themes[settings.theme].vBarStep)
//                        }
//                    }
//                        
//                    }
//                    Text("\(data.count) days").font(.caption)
//                    //Divider()
//            }
//            }
//    }
//}
