import SwiftUI
import Charts

struct ContentView: View {
    @Binding var data: DataStoreStruct
    //@State var moodSnap: MoodSnapStruct = MoodSnapStruct()
    @State var searchText: String = ""
    @State var filter: SnapTypeEnum = .none
    //let saveAction: ()->Void
    
    var body: some View {
            //VStack {
        SearchBarView(searchText: $searchText, filter: $filter, settings: $data.settings)
                HistoryView(moodSnaps: $data.moodSnaps, filter: $filter, searchText: $searchText, settings: $data.settings)
                ControlView(moodSnaps: $data.moodSnaps, settings: $data.settings)
        //}
        
//        Button("Fetch data") {
//            dist = fetchHealthData(date: Date()) + 1
//            print(dist)
//        }
//        Text("\(dist)")
    }
}
