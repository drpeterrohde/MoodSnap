import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var settings: SettingsStruct
    
    var body: some View {
        ScrollView {
            
            GroupBox(label: Label("Reminders", systemImage: "clock").foregroundColor(themes[settings.theme].iconColor)) {
                Divider()
                Toggle(isOn: $settings.reminderOn[0], label: {
                    DatePicker("Morning", selection: $settings.reminderTime[0], displayedComponents: .hourAndMinute)
                        .font(.subheadline)
                }).padding(.leading, 20)
                    .onChange(of: settings.reminderOn[0]) {newValue in 
                        toggleReminder(which: 0, settings: settings)
                    }
                    .onChange(of: settings.reminderTime[0]) {newValue in
                        updateNotifications(settings: settings)
                    }
                Toggle(isOn: $settings.reminderOn[1], label: {
                    DatePicker("Evening", selection: $settings.reminderTime[1], displayedComponents: .hourAndMinute)
                        .font(.subheadline)
                }).padding(.leading, 20)
                    .onChange(of: settings.reminderOn[1]) {newValue in 
                        toggleReminder(which: 1, settings: settings)
                    }
                    .onChange(of: settings.reminderTime[1]) {newValue in
                        updateNotifications(settings: settings)
                    }
            }
            
            GroupBox(label: Label("User interface", systemImage: "rectangle.and.hand.point.up.left.filled").foregroundColor(themes[settings.theme].iconColor)) {
                Divider()
                VStack{
                HStack {
                    Text("Theme").font(.subheadline)
                    Spacer()
                    Picker("", selection: $settings.theme) {
                        ForEach(0..<themes.count) {i in
                            Text(themes[i].name).foregroundColor(themes[settings.theme].buttonColor)
                        }
                    }
                }
                HStack {
                    Text("Grid columns").font(.subheadline)
                    Spacer()
                    Picker("", selection: $settings.numberOfGridColumns) {
                        ForEach(1..<4) {j in
                            Text("\(j)").tag(j)
                        }
                    }
                }
                }.padding(.leading, 20)
                }
                
            GroupBox(label: Label("Media", systemImage: "photo.on.rectangle.angled").foregroundColor(themes[settings.theme].iconColor)) {
                Divider()
                Toggle(isOn: $settings.saveMediaToCameraRoll, label: {
                    Text("Save media to camera roll").font(.subheadline)
                }).padding(.leading, 20)
            }
            
        GroupBox(label: Label("Symptom visibility", systemImage: "heart.text.square").foregroundColor(themes[settings.theme].iconColor)) {
            Divider()
            VStack {
                ForEach(0..<symptomList.count) {i in
                    Toggle(isOn: $settings.symptomVisibility[i], label: {
                        Text(symptomList[i]).font(.subheadline)
                    }).padding(.leading, 20)
                }
            }
        }
            
        GroupBox(label: Label("Activity visibility", systemImage: "figure.walk").foregroundColor(themes[settings.theme].iconColor)) {
            Divider()
            VStack {
                ForEach(0..<activityList.count) {i in
                    Toggle(isOn: $settings.activityVisibility[i], label: {
                        Text(activityList[i]).font(.subheadline)
                    }).padding(.leading, 20)
                }
            }
        }
            
            GroupBox(label: Label("HealthKit", systemImage: "figure.walk").foregroundColor(themes[settings.theme].iconColor)) {
                Divider()
                VStack {
                    Toggle(isOn: $settings.healthDistanceOn , label: {
                            Text("Walking & running distance").font(.subheadline)
                        }).padding(.leading, 20)
                    Toggle(isOn: $settings.healthSleepOn , label: {
                        Text("Sleep").font(.subheadline)
                    }).padding(.leading, 20)
                    Toggle(isOn: $settings.healthWeightOn , label: {
                        Text("Weight").font(.subheadline)
                    }).padding(.leading, 20)
                    Toggle(isOn: $settings.healthMenstrualOn , label: {
                        Text("Menstrual cycle").font(.subheadline)
                    }).padding(.leading, 20)
                }
            }
        }
    }
}
