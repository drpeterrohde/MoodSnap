import SwiftUI

func meanNormButterflyAverage(data: [[Double]], center: Int, minWindowSize: Int, maxWindowSize: Int) -> [Double] {
    var butterflies: [[Double]] = Array()
    let windowSize = data[0].count
    let numButterflies = data.count
    var meanZeroButterfly: [Double] = []
    
    // Generate individual mean-zero butterflies
    for thisData in data {
        let thisButterfly = normButterflyAverage(data: thisData, center: center, minWindowSize: minWindowSize, maxWindowSize: maxWindowSize)
        butterflies.append(thisButterfly)
    }
    
    // Element-wise average of mean-zero butterflies
    for i in 0...(windowSize-1) {
        var count: Int = 0
        var thisMean: Double = 0
        for j in 0...(numButterflies-1) {
            if (butterflies[j][i] >= 0) {
                count += 1
                thisMean += butterflies[j][i]
            }
        }
        if (count > 0) {
            thisMean /= Double(count)
        } else
        {
            thisMean = -1
        }
        
        meanZeroButterfly.append(thisMean)
    }
    
    return meanZeroButterfly
}
