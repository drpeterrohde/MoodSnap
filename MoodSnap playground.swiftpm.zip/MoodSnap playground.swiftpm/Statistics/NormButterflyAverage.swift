import SwiftUI

func normButterflyAverage(data: [Double], center: Int, minWindowSize: Int, maxWindowSize: Int) -> [Double] {
    let avs: [Double] = butterflyAverage(data: data, center: center, minWindowSize: minWindowSize, maxWindowSize: maxWindowSize)
    var zeroAvs: [Double] = []
    let center = avs[Int(round(Double(avs.count)/2))]
    
    for x in avs {
        zeroAvs.append(x-center)
    }
    
    return zeroAvs
}
