import SwiftUI
import Charts

struct ButterflyAverageView: View {
    var moodSnaps: [MoodSnapStruct]
    var entriesLevels: [[ChartDataEntry]]
    var entriesVolatility: [[ChartDataEntry]]
    var color: [NSUIColor]
    var timescale: TimeScaleEnum
    @Binding var settings: SettingsStruct
    @State private var selectedEvent: String = activityList[0]
    
    var body: some View {
        GroupBox(label: Label("Butterfly average", systemImage: "waveform.path.ecg.rectangle")) {
            Divider()
            VStack{
                if(entriesLevels[0].count == 0 && entriesVolatility[0].count == 0) {
                    Text("Insufficient data").foregroundColor(.primary)
                } else {
                    if (entriesLevels[0].count > 0) {
                    HStack(alignment: .center) {
                        Text("Levels").font(.caption)
                    }
                    MultipleLineChart(entries: entriesLevels, color: color, showMidBar: true, guides: 2)
                            .padding(.top, -15)
                }
                
                if (entriesVolatility[0].count > 0) {
                    HStack(alignment: .center) {
                        Text("Volatility").font(.caption)
                    }
                    MultipleLineChart(entries: entriesVolatility, color: color, showMidBar: true, guides: 2)
                        .padding(.top, -15)
                }
                
                Picker("", selection: $selectedEvent) {
                    let eventsList = getEventsList(moodSnaps: moodSnaps) 
//                    var eventStrings: [String] = []
//                    
//                    for event in eventsList {
//                        eventStrings.append("\(event.0) (\(calculateDate(date: event.1)))")
//                    }
                    
                    // Events
                    Section {
                        ForEach(0..<eventsList.count) {i in
                            Text("\(eventsList[i].0) (\(calculateDate(date: eventsList[i].1)))")
                        }
                    }
                    
                    // Activities
                    Section {
                        ForEach(0..<activityList.count) {i in
                            if (settings.activityVisibility[i]) {
                                Text(activityList.reversed()[i])
                                    .tag(activityList.reversed()[i])
                            }
                        }
                    }
                }
                }
            }
        }.frame(height: 450)
    }
}
