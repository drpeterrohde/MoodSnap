import SwiftUI
import Charts

struct MoodHistoryBarView: View {
    var entries: [[BarChartDataEntry]]
    var color: [NSUIColor]
    var timescale: TimeScaleEnum
    var settings: SettingsStruct
    
    var body: some View {
        GroupBox(label: Label("Mood history", systemImage: "chart.bar.xaxis")) {
            Divider()
                VerticalBarChart(entries: truncateEntries(data: entries[0], timescale: timescale), color: color[0], settings: settings)
                .frame(height: 65)
            Text("Elevation")
                .font(.caption)
                .foregroundColor(Color(color[0]))
                .padding([.top, .bottom], -15)
            VerticalBarChart(entries: truncateEntries(data: entries[1], timescale: timescale), color: color[1], settings: settings)
                .frame(height: 65)
                .padding(.top, -10)
            Text("Depression")
                .font(.caption)
                .foregroundColor(Color(color[1]))
                .padding([.top, .bottom], -15)
                VerticalBarChart(entries: truncateEntries(data: entries[2], timescale: timescale), color: color[2], settings: settings)
                .frame(height: 65)
                .padding(.top, -10)
            Text("Anxiety")
                .font(.caption)
                .foregroundColor(Color(color[2]))
                .padding([.top, .bottom], -15)
                VerticalBarChart(entries: truncateEntries(data: entries[3], timescale: timescale), color: color[3], settings: settings)
                .frame(height: 65)
                .padding(.top, -10)
            Text("Irritability")
                .font(.caption)
                .foregroundColor(Color(color[3]))
                .padding(.top, -15)
        }
    }
}
