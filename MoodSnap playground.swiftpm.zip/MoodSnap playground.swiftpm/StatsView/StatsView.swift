import SwiftUI
import Charts

struct StatsView: View {
    @Environment(\.presentationMode) var presentationMode
    @Binding var moodSnaps: [MoodSnapStruct]
    @Binding var settings: SettingsStruct
    @State var timescale: TimeScaleEnum = TimeScaleEnum.month
    
    var body: some View {
        
        // Mood levels
        var dataE = getAllSamples(moodSnaps: moodSnaps, type: .elevation)
        let dataD = getAllSamples(moodSnaps: moodSnaps, type: .depression)
        let dataA = getAllSamples(moodSnaps: moodSnaps, type: .anxiety)
        let dataI = getAllSamples(moodSnaps: moodSnaps, type: .irritability)
        
        let entriesE = makeBarData(y: dataE)
        let entriesD = makeBarData(y: dataD)
        let entriesA = makeBarData(y: dataA)
        let entriesI = makeBarData(y: dataI)
        
        // Sliding average
        let slidingAvE = slidingAverage(data: dataE, windowSize: settings.slidingWindowSize)
        let slidingAvD = slidingAverage(data: dataD, windowSize: settings.slidingWindowSize)
        let slidingAvA = slidingAverage(data: dataA, windowSize: settings.slidingWindowSize)
        let slidingAvI = slidingAverage(data: dataI, windowSize: settings.slidingWindowSize)
        
        let slidingAvEntriesE = makeLineData(y: slidingAvE)
        let slidingAvEntriesD = makeLineData(y: slidingAvD)
        let slidingAvEntriesA = makeLineData(y: slidingAvA)
        let slidingAvEntriesI = makeLineData(y: slidingAvI)
        
        // Volatility       
        let slidingVolE = slidingVolatility(data: dataE, windowSize: settings.slidingWindowSize)
        let slidingVolD = slidingVolatility(data: dataD, windowSize: settings.slidingWindowSize)
        let slidingVolA = slidingVolatility(data: dataA, windowSize: settings.slidingWindowSize)
        let slidingVolI = slidingVolatility(data: dataI, windowSize: settings.slidingWindowSize)
        
        let slidingVolEntriesE = makeLineData(y: slidingVolE)
        let slidingVolEntriesD = makeLineData(y: slidingVolD)
        let slidingVolEntriesA = makeLineData(y: slidingVolA)
        let slidingVolEntriesI = makeLineData(y: slidingVolI)
        
        // Butterfly average
        let dataLevelsButterflyE = butterflyAverage(data: dataE, center: 50, minWindowSize: 1, maxWindowSize: 40)
        let dataLevelsButterflyD = butterflyAverage(data: dataD, center: 50, minWindowSize: 1, maxWindowSize: 40)
        let dataLevelsButterflyA = butterflyAverage(data: dataA, center: 50, minWindowSize: 1, maxWindowSize: 40)
        let dataLevelsButterflyI = butterflyAverage(data: dataI, center: 50, minWindowSize: 1, maxWindowSize: 40)
                
//        let dataVolatilityButterflyE = butterflyAverage(data: slidingVolE, center: 50, minWindowSize: 1, maxWindowSize: 40)
//        let dataVolatilityButterflyD = butterflyAverage(data: slidingVolD, center: 50, minWindowSize: 1, maxWindowSize: 40)
//        let dataVolatilityButterflyA = butterflyAverage(data: slidingVolA, center: 50, minWindowSize: 1, maxWindowSize: 40)
//        let dataVolatilityButterflyI = butterflyAverage(data: slidingVolI, center: 50, minWindowSize: 1, maxWindowSize: 40)
//        
        let entriesButterflyE = makeLineData(y: dataLevelsButterflyE)
        let entriesButterflyD = makeLineData(y: dataLevelsButterflyD)
        let entriesButterflyA = makeLineData(y: dataLevelsButterflyA)
        let entriesButterflyI = makeLineData(y: dataLevelsButterflyI)

//        let entriesVolatilityButterflyE = makeLineData(y: dataVolatilityButterflyE)
//        let entriesVolatilityButterflyD = makeLineData(y: dataVolatilityButterflyD)
//        let entriesVolatilityButterflyA = makeLineData(y: dataVolatilityButterflyA)
//        let entriesVolatilityButterflyI = makeLineData(y: dataVolatilityButterflyI)
        
        VStack {
        Picker("", selection: $timescale) {
            Text("1mo").tag(TimeScaleEnum.month)
            Text("3mo").tag(TimeScaleEnum.threeMonths)
            Text("6mo").tag(TimeScaleEnum.sixMonths)
            Text("1yr").tag(TimeScaleEnum.year)
        }.pickerStyle(SegmentedPickerStyle())
        
        ScrollView(.vertical) {
            VStack{
                MoodHistoryBarView(
                    entries: [entriesE, entriesD, entriesA, entriesI],
                    color: themes[settings.theme].moodColors,
                    timescale: timescale, settings: settings)
                
                SlidingAverageView(
                    entries: [slidingAvEntriesE, slidingAvEntriesD, slidingAvEntriesA, slidingAvEntriesI],
                    color: themes[settings.theme].moodColors,
                    timescale: timescale)
                
                SlidingVolatilityView(
                    entries: [slidingVolEntriesE, slidingVolEntriesD, slidingVolEntriesA, slidingVolEntriesI],
                    color: themes[settings.theme].moodColors,
                    timescale: timescale)

                ButterflyAverageView(
                    moodSnaps: moodSnaps,
                    entriesLevels: [entriesButterflyE, entriesButterflyD, entriesButterflyA, entriesButterflyI],
                    entriesVolatility: [entriesButterflyE, entriesButterflyD, entriesButterflyA, entriesButterflyI], // change to volatility ???
                    color: themes[settings.theme].moodColors,
                    timescale: timescale,
                    settings: $settings)
                
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "stop.circle").resizable().scaledToFill().frame(width: 30, height: 30)
            }
            }
            }
        }
    }
}
