import SwiftUI

func makeDemoData(size: Int) -> [MoodSnapStruct] {
    var moodSnaps: [MoodSnapStruct] = []
    let max = 50
    
    // Segment
    for i in 1...max {
        var moodSnap = MoodSnapStruct()
        moodSnap.elevation = Double(Int.random(in: 1...2))
        moodSnap.depression = Double(Int.random(in: 3...4))
        moodSnap.anxiety = round(Double.random(in: 0...0.6))
        moodSnap.irritability = round(Double.random(in: 1...1.6))
        moodSnaps.append(moodSnap)
    }
    
    // Segment
    for i in 1...max {
        var moodSnap = MoodSnapStruct()
        moodSnap.elevation = round(Double(max-i)*Double(Int.random(in: 0...4))/Double(max))
        moodSnap.depression = round(Double(i)*Double(Int.random(in: 0...4))/Double(max))
        moodSnap.anxiety = round(Double.random(in: 0...0.9))
        moodSnap.irritability = round(Double.random(in: 1...1.8))
        moodSnaps.append(moodSnap)
    }
    
    return moodSnaps
}

