import SwiftUI

struct SettingsStruct: Identifiable, Codable {
    var id: UUID = UUID()
    
    var symptomVisibility: [Bool] = [Bool](repeating: true, count: symptomList.count)
    var activityVisibility: [Bool] = [Bool](repeating: true, count: activityList.count)
    var reminderOn: [Bool] = [false, false]
    var reminderTime: [Date] = [
        Calendar.current.date(from: DateComponents(hour: 8, minute: 0))!,
        Calendar.current.date(from: DateComponents(hour: 20, minute: 0))!
    ]
    var healthDistanceOn: Bool = false
    var healthMenstrualOn: Bool = false
    var healthSleepOn: Bool = false
    var healthWeightOn: Bool = false
    
    var numberOfGridColumns: Int = 3
    var slidingWindowSize: Int = 14
    
    var saveMediaToCameraRoll: Bool = true
    
    var theme: Int = 0
}
struct MoodSnapStruct: Identifiable, Codable {
    var id: UUID = UUID()
    var timestamp: Date = Date()
    var snapType: SnapTypeEnum = .mood
    
    // Mood
    var elevation: CGFloat = 0.0
    var depression: CGFloat = 0.0
    var anxiety: CGFloat = 0.0
    var irritability: CGFloat = 0.0
    
    // Symptoms
    var symptoms = [Bool](repeating: false, count: symptomList.count)
    
    // Activities
    var activities = [Bool](repeating: false, count: activityList.count)
    
    // Event
    var event: String = ""
    
    // Notes
    var notes: String = ""
}
