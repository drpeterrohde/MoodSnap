import SwiftUI

enum SnapTypeEnum: Encodable, Decodable {
    case none
    case mood
    case note
    case event
    case media
}

enum MoodsEnum {
    case elevation
    case depression
    case anxiety
    case irritability
}

enum TimeScaleEnum:Int {
    case month = 30
    case threeMonths = 90
    case sixMonths = 180
    case year = 365
}
