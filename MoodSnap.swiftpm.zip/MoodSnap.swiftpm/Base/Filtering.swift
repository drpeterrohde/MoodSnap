import SwiftUI

func getAllSamples(moodSnaps: [MoodSnapStruct], type: MoodsEnum) -> [Double] {
    var samples: [Double] = []
    
    for moodSnap in moodSnaps.reversed() {
        if (moodSnap.snapType == .mood) {
            switch type {
            case .elevation:
                samples.append(moodSnap.elevation)
            case .depression:
                samples.append(moodSnap.depression)
            case .anxiety:
                samples.append(moodSnap.anxiety)
            case .irritability:
                samples.append(moodSnap.irritability)
            }
        }
    }
    
    return samples
}

func getSamplesByDate(moodSnaps: [MoodSnapStruct], endDate: Date, windowInterval: Double, type: MoodsEnum) -> [Double] {
    let startDate = endDate.addingTimeInterval(-windowInterval)
    let dateRange = startDate ... endDate
    var samples: [Double] = []
    
    for moodSnap in moodSnaps {
        if (moodSnap.snapType == .mood) {
            if dateRange.contains(moodSnap.timestamp) {
                switch type {
                case .elevation:
                    samples.append(moodSnap.elevation)
                case .depression:
                    samples.append(moodSnap.depression)
                case .anxiety:
                    samples.append(moodSnap.anxiety)
                case .irritability:
                    samples.append(moodSnap.irritability)
                }
            }
        }
    }
    
    return samples
}

func sortByDate(moodSnaps: [MoodSnapStruct]) -> [MoodSnapStruct] {
    let newMoodSnaps: [MoodSnapStruct] = moodSnaps.sorted(by: {
        $0.timestamp.compare($1.timestamp) == .orderedDescending
    })
    return newMoodSnaps
}

func getEventsList(moodSnaps: [MoodSnapStruct]) -> [(String, Date)] {
    var list: [(String, Date)] = []
    
    for moodSnap in moodSnaps {
        if (moodSnap.snapType == .event) {
            list.append((moodSnap.event, moodSnap.timestamp))
        }
    }
    
    return list
}

func getMoodSnapByUUID(moodSnaps: [MoodSnapStruct], id: UUID) -> MoodSnapStruct? {
    if let item = moodSnaps.first(where: { $0.id == id }) {
        return item
    }
    return nil
}

func getMoodSnapByDate(moodSnaps: [MoodSnapStruct], date: DateComponents) -> [MoodSnapStruct] {
    let items = moodSnaps.filter {
        Calendar.current.date($0.timestamp, matchesComponents: date)
    }
    
    return items
}

func collapseMoodSnapsIntoDay(moodSnaps: [MoodSnapStruct]) -> MoodSnapStruct? {
    if (moodSnaps.count == 0) {
        return nil
    }
    
    var collapsed = MoodSnapStruct()
    
    for moodSnap in moodSnaps {
        collapsed.timestamp = moodSnap.timestamp
        collapsed.elevation = max(collapsed.elevation, moodSnap.elevation)
        collapsed.depression = max(collapsed.depression, moodSnap.elevation)
        collapsed.anxiety = max(collapsed.anxiety, moodSnap.elevation)
        collapsed.irritability = max(collapsed.irritability, moodSnap.elevation)
    
        for i in 0..<symptomList.count {
            collapsed.symptoms[i] = collapsed.symptoms[i] && moodSnap.symptoms[i]
        }
    
        for i in 0..<activityList.count {
            collapsed.activities[i] = collapsed.activities[i] && moodSnap.activities[i]
        }
    }
    
    return collapsed
}

func getEarliestDate(moodSnaps: [MoodSnapStruct]) -> Date {
    var orderedList = sortByDate(moodSnaps: moodSnaps)
    orderedList.append(MoodSnapStruct())
    return orderedList[0].timestamp
}

func snapFilter(moodSnap: MoodSnapStruct, filter: SnapTypeEnum, searchText: String) -> Bool {
    let filterOutcome =
    (filter == .mood && moodSnap.snapType == .mood) || 
    (filter == .event && moodSnap.snapType == .event) || 
    (filter == .note && moodSnap.snapType == .note) ||
    (filter == .media && moodSnap.snapType == .media)
    
    if filterOutcome { return true }
    
    if (filter == .none) {
        let eventTextOutcome = moodSnap.event.contains(searchText) || (searchText == "")
        let notesTextOutcome = moodSnap.notes.contains(searchText)  || (searchText == "")
        
        if (eventTextOutcome || notesTextOutcome) { return true}
    }
    
    return false
}
