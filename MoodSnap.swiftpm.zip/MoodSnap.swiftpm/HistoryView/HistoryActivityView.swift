import SwiftUI

struct HistoryActivityView: View {
    let moodSnap: MoodSnapStruct
    let settings: SettingsStruct
    
    var body: some View {
        let gridItemLayout = Array(repeating: GridItem(.flexible()), count: settings.numberOfGridColumns)
        
        LazyVGrid(columns: gridItemLayout, spacing: themes[settings.theme].historyGridSpacing) {
            ForEach(0..<activityList.count) {i in
                if (moodSnap.activities[i] && settings.activityVisibility[i]) {
                    Text(activityList[i])
                        .font(.caption)
                        .foregroundColor(themes[settings.theme].buttonColor)
                        .multilineTextAlignment(.center)
                }
            }
        }
    }
}
