import SwiftUI

struct HistoryMoodView: View {
    let moodSnap: MoodSnapStruct
    let settings: SettingsStruct
    
    var body: some View {
        Divider()
        MoodLevelsView(moodSnap: moodSnap, settings: settings)

        Group {
            if(totalSymptoms(moodSnap: moodSnap, settings: settings) != 0) {
                Divider()
                Label("Symptoms", systemImage: "heart.text.square").font(.caption)
                HistorySymptomsView(moodSnap: moodSnap, settings: settings)
            }
        }
        
        Group {
            if(totalActivities(moodSnap: moodSnap, settings: settings) != 0) {
                Divider()
                Label("Activity", systemImage: "figure.walk").font(.caption)
                HistoryActivityView(moodSnap: moodSnap, settings: settings)
            }
        }
        
        if (!(String(moodSnap.notes).isEmpty)) {
            Group {
                Divider()
                Spacer()
                Text(String(moodSnap.notes)).font(.caption).padding(-5).frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}
