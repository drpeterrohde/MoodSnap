import SwiftUI

struct HistorySymptomsView: View {
    let moodSnap: MoodSnapStruct
    let settings: SettingsStruct
    
    var body: some View {
        let gridItemLayout = Array(repeating: GridItem(.flexible()), count: settings.numberOfGridColumns)
        
        LazyVGrid(columns: gridItemLayout, spacing: themes[settings.theme].historyGridSpacing) {
            ForEach(0..<symptomList.count) {i in
                if (moodSnap.symptoms[i] && settings.symptomVisibility[i]) {
                    Text(symptomList[i]).font(.caption).foregroundColor(themes[settings.theme].buttonColor).multilineTextAlignment(.center)
                }
            }
        }
    }
}
