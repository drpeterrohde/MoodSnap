//import SwiftUI
//
//struct DatePickerView: View {
//    @Environment(\.dismiss) var dismiss
//    @Binding var moodSnaps: [MoodSnapStruct]
//    var moodSnap: MoodSnapStruct
//        
//    var body: some View {
//        GroupBox {
//            Text("Date page")
//            
//            DatePicker(
//                "Start Date",
//                selection: $moodSnap.timestamp,
//                displayedComponents: [.date, .hourAndMinute]
//            )
//        }
//    }
//}
