import SwiftUI

struct MoodSnapView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var moodSnaps: [MoodSnapStruct]
    @State var moodSnap: MoodSnapStruct
    @Binding var settings: SettingsStruct
    @State private var showingDatePickerSheet = false
    
    var body: some View {
        GroupBox {
            ScrollView {
            Group {
            HStack{
                Label(calculateDateAndTime(date: moodSnap.timestamp), systemImage: "clock").font(.caption)
                
                Spacer()
                
                Button {
                    //showingDatePickerSheet.toggle()
                } label:{Image(systemName: "calendar.badge.clock").resizable().scaledToFill().frame(width: 15, height: 15).foregroundColor(Color.white)
                }//.sheet(isPresented: $showingDatePickerSheet) {
                    //DatePickerView()
                //}
            }
            }
            
            // Mood
            Group {
                Divider()
            VStack(spacing: themes[settings.theme].sliderSpacing) {
                Label("Mood", systemImage: "brain.head.profile").font(.caption)
                Spacer().frame(height: 20)
                Text("Elevation").font(Font.caption.bold()).foregroundColor(themes[settings.theme].elevationColor)
                    Slider(value: $moodSnap.elevation, in: 0...4, step: 1)
                Text("Depression").font(Font.caption.bold()).foregroundColor(themes[settings.theme].depressionColor)
                    Slider(value: $moodSnap.depression, in: 0...4, step: 1)
                Text("Anxiety").font(Font.caption.bold()).foregroundColor(themes[settings.theme].anxietyColor)
                Slider(value: $moodSnap.anxiety, in: 0...4, step: 1)
                Text("Irritability").font(Font.caption.bold()).foregroundColor(themes[settings.theme].irritabilityColor)
                Slider(value: $moodSnap.irritability, in: 0...4, step: 1)
            }
            }
            
            // Symptoms
            Group {
            Divider()
            Label("Symptoms", systemImage: "heart.text.square").font(.caption)
            
                let gridItemLayout = Array(repeating: GridItem(.flexible()), count: settings.numberOfGridColumns)
                
            LazyVGrid(columns: gridItemLayout, spacing: themes[settings.theme].moodSnapGridSpacing) {
                    ForEach(0..<symptomList.count) {i in
                        if (settings.symptomVisibility[i]) {
                        Toggle(symptomList[i], isOn: $moodSnap.symptoms[i])
                            .toggleStyle(.button)
                            .tint(themes[settings.theme].buttonColor)
                            .font(.caption)
                            .padding(0)
                        }
                    }
            }
            }
            
            // Activities
            Group {
            Divider()
            Label("Activity", systemImage: "figure.walk").font(.caption)
            
                let gridItemLayout = Array(repeating: GridItem(.flexible()), count: settings.numberOfGridColumns)
            
            LazyVGrid(columns: gridItemLayout, spacing: themes[settings.theme].moodSnapGridSpacing) {
                ForEach(0..<activityList.count) {i in
                    if (settings.activityVisibility[i]) {
                    Toggle(activityList[i], isOn: $moodSnap.activities[i])
                        .toggleStyle(.button)
                        .tint(themes[settings.theme].buttonColor)
                        .font(.caption)
                    }
                }
            }
            }
            
            // Notes
            Group {
                VStack{
                    Divider()
                Label("Notes", systemImage: "note.text").font(.caption)
                TextEditor(text: $moodSnap.notes).font(.caption).frame(minHeight: 50, alignment: .leading)
                }
            }
            
            // Save button
            Button {
                moodSnap.snapType = .mood
                moodSnaps = deleteHistoryItem(moodSnaps: moodSnaps, moodSnap: moodSnap)
                moodSnaps.append(moodSnap)
                moodSnaps = sortByDate(moodSnaps: moodSnaps)
                dismiss()
            } label:{Image(systemName: "arrowtriangle.right.circle").resizable().scaledToFill().frame(width: 30, height: 30)
            }
        }
        }
    }
}
