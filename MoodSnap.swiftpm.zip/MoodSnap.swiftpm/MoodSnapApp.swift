import SwiftUI

@main
struct MoodSnapApp: App {
    //@StateObject private var store: DataStore = DataStore()
    @State private var data: DataStoreStruct = DataStoreStruct()
    
    var body: some Scene {
        WindowGroup {
            //HistoryView(moodSnaps: moodSnaps)
            //MoodSnapView()
            //StatsView(moodSnaps: moodSnaps)
            ContentView(data: $data)//, saveAction: {
//                DataStore.save(data: store.data) { result in
//                    if case .failure(let error) = result {
//                        fatalError(error.localizedDescription)
//                    }
//                }
//            })
//            .onAppear {
//                DataStore.load { result in
//                    switch result {
//                    case .failure(let error):
//                        fatalError(error.localizedDescription)
//                    case .success(let data):
//                        store.data = data
//                    }
//                }
            //}
        }
    }
}

// To do

// Slider tick marks
// Adjustable times
// HealthKit:
//     Weight
//     Active energy
//     Sleep
//     Menstrual cycle
// Make iPhone only (type 1)
// Confidence
// Persistent data
// Import/export JSON format
// Reminders
// Editing & deleting
// Date filter

/*
 https://github.com/danielgindi/Charts (SwiftUI charts
 )
 https://github.com/AppPear/ChartView (Good multi-line and column)
 https://github.com/spacenation/swiftui-charts (Stacked column good)
 https://github.com/captain-camel/CoreCharts
 https://github.com/Wittenstam/SwiftBI (Check it)
 https://github.com/philackm/ScrollableGraphView
 https://fellrnr.com/wiki/Modeling_Human_Performance#The_TSB_Model (TSB model)
 */

/*
 
 Suggestions from Emma:
 
 Some will be both ASD & ADHD
 
 Stimming
 Sensory overload ‘ring of fire’ 
 forgetfulness 
 Impatience 
 Negative self-talk / internal shame monologue (I’m not really sure what to call this but it’s a really common experience - for me it’s the thing most helped by meds) 
 Insomnia
 AM fatigue 
 Object permanence (kind of forgetfulness but specifically it present as a million half completed jobs abandoned in one’s wake)
 
 */
