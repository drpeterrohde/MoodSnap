//import SwiftUI
//import PDFKit
//
//func generatePDF() {
//    let pdfMetaData = [kCGPDFContextCreator: "Mood report",
//                        kCGPDFContextAuthor: "www.moodsnap.app"]
//    
//    let format = UIGraphicsPDFRendererFormat() 
//    format.documentInfo = pdfMetaData as [String: Any]
//    
//    let pageWidth = 8.5 * 72.0
//    let pageHeight = 11 * 72.0
//    let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
//    
//    let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)
//    
//    let data = renderer.pdfData { (context) in
//        context.beginPage()
//        let attributes = [
//            NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 72)
//        ]
//        let text = "I'm a PDF!"
//        text.draw(at: CGPoint(x: 0, y: 0), withAttributes: attributes)
//    }
//    
//    return data
//    
//    let pdfView = PDFView()
//    pdfView.autoScales = true
//    pdfView.document = PDFDocument(data: data)
//    
//    
//}
