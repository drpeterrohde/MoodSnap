import SwiftUI

func average(data: [Double]) -> Double {
    var sum: Double = 0
    var count: Double = 0
    var av: Double = 0
    
    for x in data {
        if (x >= 0) {
            sum += x
            count += 1
        }
    }
    
    if (count > 0) {
        av = sum / count
    }
    
    return av
}
