import SwiftUI

func butterflyAverage(data: [Double], center: Int, minWindowSize: Int, maxWindowSize: Int) -> [Double] {
    var avs: [Double] = []
    
    for windowSize in stride(from: maxWindowSize, to: minWindowSize, by: -1) {
        let thisAv = average(data: Array(data[(center-windowSize)...center]))
        avs.append(thisAv)
    }
    
    for windowSize in stride(from: minWindowSize, to: maxWindowSize, by: 1) {
        let thisAv = average(data: Array(data[center...(center+windowSize)]))
        avs.append(thisAv)
    }
    
    return avs
}
