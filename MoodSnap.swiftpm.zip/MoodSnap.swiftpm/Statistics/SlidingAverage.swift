import SwiftUI

func slidingAverage(data: [Double], windowSize: Int) -> [Double] {
    var avs: [Double] = []
    var thisAv: Double = 0
    
    if (data.count > windowSize) {
        for offset in 1...(data.count-windowSize-1) {
            thisAv = average(data: Array(data[offset...(offset+windowSize)]))
            avs.append(thisAv)
        }
    } else {
        thisAv = average(data: data)
        avs.append(thisAv)
    }
    
    return avs
}
