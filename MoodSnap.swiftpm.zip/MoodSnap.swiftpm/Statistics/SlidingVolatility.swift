import SwiftUI

func slidingVolatility(data: [Double], windowSize: Int) -> [Double] {
    var vols: [Double] = []
    var thisStdDev: Double = 0
    
    if (data.count > windowSize) {
        for offset in 1...(data.count-windowSize-1) {
            thisStdDev = volatility(data: Array(data[offset...(offset+windowSize)]))
            vols.append(thisStdDev)
        }
    } else {
        thisStdDev = volatility(data: data)
        vols.append(thisStdDev)
    }
    
    return vols
}
