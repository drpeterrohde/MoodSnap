import SwiftUI

func volatility(data: [Double]) -> Double {
    var sum: Double = 0
    var count: Double = 0
    let av = average(data: data)
    var stdDev: Double = 0
    
    for x in data {
        if (x >= 0) {
            sum += pow(x - av, 2)
            count += 1
        }
    }
    
    if (count > 0) {
        stdDev = sqrt(sum / count)
    }
    
    return stdDev
}
