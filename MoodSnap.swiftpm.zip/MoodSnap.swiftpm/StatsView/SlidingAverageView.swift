import SwiftUI
import Charts

struct SlidingAverageView: View {
    var entries: [[ChartDataEntry]]
    var color: [NSUIColor]
    var timescale: TimeScaleEnum
    
    var body: some View {
        GroupBox(label: Label("Moving average", systemImage: "chart.line.uptrend.xyaxis")) {
            Divider()
            MultipleLineChart(entries: truncateEntriesArray(data: entries, timescale: timescale), color: color)
        }.frame(height: 250)
    }
}
