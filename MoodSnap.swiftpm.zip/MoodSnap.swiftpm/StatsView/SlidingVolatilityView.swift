import SwiftUI
import Charts

struct SlidingVolatilityView: View {
    var entries: [[ChartDataEntry]]
    var color: [NSUIColor]
    var timescale: TimeScaleEnum
    
    var body: some View {
        GroupBox(label: Label("Volatility", systemImage: "waveform.path.ecg")) {
            Divider()
            MultipleLineChart(entries: truncateEntriesArray(data: entries, timescale: timescale), color: color, max: 2, guides: 2)
        }.frame(height: 250)
    }
}
